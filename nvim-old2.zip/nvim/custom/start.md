# NeoVim Start Page

## dotfiles

~/.config/nvim/init.vim

## Command
